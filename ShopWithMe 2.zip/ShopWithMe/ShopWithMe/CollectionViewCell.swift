//
//  CollectionViewCell.swift
//  ShopWithMe
//
//  Created by Kushani Jayawardane on 9/10/19.
//  Copyright © 2019 Kushani Jayawardane. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    

    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var label1: UILabel!
    
    @IBOutlet weak var label2: UILabel!
    
    
}
