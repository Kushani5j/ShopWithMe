//
//  CartViewController.swift
//  ShopWithMe
//
//  Created by Kushani Jayawardana on 9/25/19.
//  Copyright © 2019 Kushani Jayawardane. All rights reserved.
//

import UIKit

class CartViewController: UIViewController {

    @IBOutlet weak var priceLbl: UILabel!
    
    @IBOutlet weak var totLbl: UILabel!
    @IBAction func Stepper_Changed(_ sender: UIStepper) { QtyLbl.text = Int(sender.value).description
        var pr = v * Double(sender.value)
        priceLbl.text = pr.description
        
    
    }
    var priceDo: Double? {
        if let value = priceLbl.text ?? nil {
            return Double(value)
        }
        return 0
    }
    var v = 0.00;
    @IBOutlet weak var QtyLbl: UILabel!
    
    @IBOutlet weak var stepper: UIStepper!
    override func viewDidLoad() {
        super.viewDidLoad()
        stepper.wraps = true
        stepper.autorepeat = true
        stepper.maximumValue = 10
        v = Double(priceDo!)// Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
